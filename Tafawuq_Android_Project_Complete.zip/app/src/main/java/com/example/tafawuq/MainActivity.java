package com.example.tafawuq;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int blue = Color.rgb(43, 76, 210);
    private final int pale = Color.rgb(232, 244, 255);
    private int score = 0, questionIndex = 0;
    private LinearLayout root;
    private final Button[] optionButtons = new Button[4];
    private final String[] questions = {
        "ما الكوكب المعروف بالكوكب الأحمر؟",
        "ما العملية التي تصنع بها النباتات غذاءها؟",
        "كم يساوي ٧ × ٨؟"
    };
    private final String[][] choices = {
        {"الأرض", "المريخ", "الزهرة", "المشتري"},
        {"التنفس", "التبخر", "البناء الضوئي", "الهضم"},
        {"٥٤", "٥٦", "٦٤", "٤٨"}
    };
    private final int[] correctAnswers = {1, 2, 1};

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(blue);
        getWindow().setNavigationBarColor(blue);
        showHome();
    }
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius); return d;
    }
    private TextView makeText(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size);
        t.setTextColor(color); t.setGravity(Gravity.CENTER); t.setPadding(16,12,16,12);
        if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private Button makeButton(String value) {
        Button b = new Button(this); b.setText(value); b.setTextSize(17);
        b.setTextColor(blue); b.setAllCaps(false); b.setBackground(rounded(Color.WHITE,28)); return b;
    }
    private void setup() {
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(20,24,20,20); root.setBackgroundColor(pale);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL); setContentView(root);
    }
    private void showHome() {
        setup();
        root.addView(makeText("تَفَوُّق 📚",32,blue,true));
        root.addView(makeText("رحلتك نحو التميّز تبدأ من هنا",17,Color.DKGRAY,false));
        TextView welcome = makeText("مرحباً بك في تفوق\\nتعلّم، اختبر نفسك، واكتشف تقدمك!",21,Color.WHITE,true);
        welcome.setBackground(rounded(blue,30));
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1,180);
        wp.setMargins(0,24,0,20); root.addView(welcome,wp);
        root.addView(makeText("اختر مادة وابدأ الاختبار",20,blue,true));
        for (String subject : new String[]{"العلوم","الرياضيات","اللغة العربية"}) {
            Button b = makeButton(subject+"  ←");
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,62);
            p.setMargins(0,7,0,7); root.addView(b,p);
            b.setOnClickListener(v -> { questionIndex=0; score=0; showQuestion(); });
        }
        root.addView(makeText("⭐ نقاطك في هذه الجولة: "+score,17,blue,true));
    }
    private void showQuestion() {
        setup();
        root.addView(makeText("اختبار تفاعلي",26,blue,true));
        root.addView(makeText("السؤال "+(questionIndex+1)+" من "+questions.length+"  |  النقاط: "+score,16,Color.DKGRAY,true));
        TextView prompt = makeText(questions[questionIndex],22,Color.BLACK,true);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-1,150);
        pp.setMargins(0,20,0,16); root.addView(prompt,pp);
        for (int i=0;i<4;i++) {
            final int selected=i; optionButtons[i]=makeButton(choices[questionIndex][i]);
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,60);
            p.setMargins(0,6,0,6); root.addView(optionButtons[i],p);
            optionButtons[i].setOnClickListener(v -> submitAnswer(selected));
        }
    }
    private void submitAnswer(int selected) {
        for (Button b:optionButtons) b.setEnabled(false);
        if (selected==correctAnswers[questionIndex]) {
            score+=10; Toast.makeText(this,"إجابة صحيحة! أحسنت ⭐",Toast.LENGTH_SHORT).show();
        } else Toast.makeText(this,"ليست الإجابة الصحيحة، واصل التعلّم!",Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(() -> {
            questionIndex++;
            if (questionIndex<questions.length) showQuestion(); else showResult();
        },800);
    }
    private void showResult() {
        setup(); root.addView(makeText("أحسنت! انتهى الاختبار 🎉",25,blue,true));
        root.addView(makeText("نتيجتك: "+score+" من 30",29,blue,true));
        Button home=makeButton("العودة إلى الرئيسية"); root.addView(home); home.setOnClickListener(v->showHome());
        Button retry=makeButton("إعادة الاختبار"); root.addView(retry);
        retry.setOnClickListener(v->{questionIndex=0;score=0;showQuestion();});
    }
}
